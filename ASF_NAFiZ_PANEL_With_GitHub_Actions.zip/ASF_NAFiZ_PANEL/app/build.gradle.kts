plugins { id("com.android.application") }

android {
    namespace = "com.asf.nafizpanel"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.asf.nafizpanel"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
