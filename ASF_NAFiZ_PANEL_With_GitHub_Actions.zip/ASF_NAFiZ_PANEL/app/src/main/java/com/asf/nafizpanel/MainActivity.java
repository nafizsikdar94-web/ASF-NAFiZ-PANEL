package com.asf.nafizpanel;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    final int BG=Color.rgb(7,9,13), PANEL=Color.rgb(16,20,27), WHITE=Color.rgb(245,247,250),
              MUTED=Color.rgb(142,153,170), GREEN=Color.rgb(22,214,122);
    LinearLayout root, content;
    TextView timer,status;
    CountDownTimer cd;

    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    TextView tv(String s,int sp,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.BLACK); b.setTextSize(13); b.setAllCaps(false); b.setBackground(bg(GREEN,18)); return b; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); showLogin(); }

    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(28,28,28,28); root.setBackgroundColor(BG); setContentView(root);
    }
    void showLogin(){
        base();
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,28,24,28); box.setGravity(Gravity.CENTER); box.setBackground(bg(PANEL,28));
        TextView title=tv("ASF NAFiZ PANEL",27,WHITE); title.setGravity(Gravity.CENTER); box.addView(title,new LinearLayout.LayoutParams(-1,60));
        TextView sub=tv("PRIVATE PANEL • LOGIN REQUIRED",11,MUTED); sub.setGravity(Gravity.CENTER); box.addView(sub,new LinearLayout.LayoutParams(-1,35));
        EditText pass=new EditText(this); pass.setHint("Enter password"); pass.setHintTextColor(MUTED); pass.setTextColor(WHITE); pass.setInputType(0x81);
        pass.setSingleLine(true); pass.setPadding(18,0,18,0); pass.setBackground(bg(Color.rgb(8,11,16),18));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,54); ep.topMargin=18; box.addView(pass,ep);
        Button login=btn("UNLOCK PANEL"); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,52); lp.topMargin=16; box.addView(login,lp);
        TextView hint=tv("Password: NOMANBHAI",11,MUTED); hint.setGravity(Gravity.CENTER); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,40); hp.topMargin=8; box.addView(hint,hp);
        login.setOnClickListener(v->{ if("NOMANBHAI".equals(pass.getText().toString())) showPanel(); else { pass.setError("Wrong password"); }});
        root.addView(box,new LinearLayout.LayoutParams(-1,-2));
    }
    void showPanel(){
        base();
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(20,20,20,20); content.setBackground(bg(PANEL,26));
        ScrollView sv=new ScrollView(this); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,-1));
        TextView title=tv("ASF NAFiZ PANEL",27,WHITE); title.setGravity(Gravity.CENTER); content.addView(title,new LinearLayout.LayoutParams(-1,58));
        TextView sub=tv("CUSTOM PRANK • DEMO MODE",11,MUTED); sub.setGravity(Gravity.CENTER); content.addView(sub,new LinearLayout.LayoutParams(-1,30));
        addToggle("Headshot Mode","Visual toggle only");
        addToggle("Aim Assist","Visual toggle only");
        addToggle("Auto Target","Visual toggle only");
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.VERTICAL); stats.setPadding(14,8,14,8); stats.setBackground(bg(Color.rgb(8,11,16),16));
        TextView hs=tv("HS: 100%",16,WHITE); hs.setGravity(Gravity.CENTER_VERTICAL); stats.addView(hs,new LinearLayout.LayoutParams(-1,44));
        status=tv("STATUS: READY",14,WHITE); stats.addView(status,new LinearLayout.LayoutParams(-1,40));
        content.addView(stats,new LinearLayout.LayoutParams(-1,-2));
        Button start=btn("START 30 MIN TRIAL"); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,52); sp.topMargin=16; content.addView(start,sp);
        timer=tv("30:00",28,WHITE); timer.setGravity(Gravity.CENTER); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,62); content.addView(timer,tp);
        TextView fake=tv("Tap the button below to simulate a headshot event",11,MUTED); fake.setGravity(Gravity.CENTER); content.addView(fake,new LinearLayout.LayoutParams(-1,34));
        Button event=btn("SIMULATE HEADSHOT 🔥"); LinearLayout.LayoutParams ev=new LinearLayout.LayoutParams(-1,50); content.addView(event,ev);
        TextView note=tv("Harmless demo — does not modify Free Fire.",10,MUTED); note.setGravity(Gravity.CENTER); content.addView(note,new LinearLayout.LayoutParams(-1,46));
        start.setOnClickListener(v->startTimer());
        event.setOnClickListener(v->{ Toast.makeText(this,"HEADSHOT DETECTED 🔥",Toast.LENGTH_LONG).show(); status.setText("STATUS: HEADSHOT DETECTED 🔥"); });
    }
    void addToggle(String name,String desc){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,5,0,5);
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv(name,15,WHITE), d=tv(desc,10,MUTED); texts.addView(a,new LinearLayout.LayoutParams(0,30,1)); texts.addView(d,new LinearLayout.LayoutParams(0,22,1));
        Switch sw=new Switch(this); sw.setText("ON"); sw.setTextColor(MUTED); sw.setChecked(true);
        row.addView(texts,new LinearLayout.LayoutParams(0,62,1)); row.addView(sw,new LinearLayout.LayoutParams(85,62));
        content.addView(row,new LinearLayout.LayoutParams(-1,68));
    }
    void startTimer(){
        if(cd!=null)return;
        status.setText("STATUS: ACTIVE");
        cd=new CountDownTimer(30*60*1000L,1000){
            public void onTick(long ms){ long s=ms/1000; timer.setText(String.format(Locale.US,"%02d:%02d",s/60,s%60)); }
            public void onFinish(){ timer.setText("00:00"); status.setText("STATUS: TRIAL EXPIRED 😂"); Toast.makeText(MainActivity.this,"TRIAL EXPIRED 😂",Toast.LENGTH_LONG).show(); cd=null; }
        }.start();
    }
}