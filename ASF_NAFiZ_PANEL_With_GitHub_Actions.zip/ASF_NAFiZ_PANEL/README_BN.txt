ASF NAFiZ PANEL — SAFE PRANK DEMO
=================================

Password: NOMANBHAI

This app is a harmless visual prank/demo. It does NOT modify Free Fire,
aiming, memory, game files, or anti-cheat systems.

BUILD ON WINDOWS
1. Install Android Studio from:
   https://developer.android.com/studio
2. Open Android Studio.
3. File > Open, then select this ASF_NAFiZ_PANEL folder.
4. Wait for Gradle Sync to finish and install any suggested SDK components.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a link to the generated APK.
   Typical path: app/build/outputs/apk/debug/app-debug.apk

INSTALL ON YOUR MOTOROLA PHONE
1. Copy app-debug.apk to your phone (USB, Google Drive, etc.).
2. Tap the APK in Files.
3. If Android asks for permission, allow your file manager/browser
   to install unknown apps.
4. Tap Install.
5. Open "ASF NAFiZ PANEL".
6. Password: NOMANBHAI

ALTERNATIVE USB INSTALL
With USB debugging enabled:
adb install app/build/outputs/apk/debug/app-debug.apk

The Android documentation confirms Android Studio can build/install an APK
and ADB can install an APK on a connected device.
